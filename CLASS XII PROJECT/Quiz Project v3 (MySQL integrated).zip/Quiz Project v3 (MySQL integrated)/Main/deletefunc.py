import mysql.connector as mycon
mydb = mycon.connect(host = "localhost", user = "root", password = "mysql", database = "Quiz")
mycursor = mydb.cursor()

def value(x):
    return(str(x.get()))

def delete(x, lbl):
    y = value(x)
    st = "delete from admin where username = '{}';".format(y)
    mycursor.execute(st)
    mydb.commit()
    lbl["text"] = "Deleted succesfully"

def home(lbl):
    lbl["text"] = ""