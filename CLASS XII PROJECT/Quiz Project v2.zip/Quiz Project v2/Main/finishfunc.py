def reset(lbl1, lbl2):
    lbl1["text"] = ""
    lbl2["text"] = ""